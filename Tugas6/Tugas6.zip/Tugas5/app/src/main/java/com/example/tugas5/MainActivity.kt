package com.example.tugas5

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etTanggal: EditText
    private lateinit var etJam: EditText
    private lateinit var btnTanggal: ImageButton
    private lateinit var btnJam: ImageButton
    private lateinit var btnToast: Button

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etTanggal = findViewById(R.id.etTanggal)
        etJam = findViewById(R.id.etJam)
        btnTanggal = findViewById(R.id.btnTanggal)
        btnJam = findViewById(R.id.btnJam)
        btnToast = findViewById(R.id.btnToast)

        btnTanggal.setOnClickListener {
            Log.d(TAG, "Tombol tanggal ditekan.")
            tampilkanDatePicker()
        }

        etTanggal.setOnClickListener {
            Log.d(TAG, "EditText tanggal ditekan.")
            tampilkanDatePicker()
        }

        // Listener tombol jam
        btnJam.setOnClickListener {
            Log.d(TAG, "Tombol jam ditekan.")
            tampilkanTimePicker()
        }

        etJam.setOnClickListener {
            Log.d(TAG, "EditText jam ditekan.")
            tampilkanTimePicker()
        }

        btnToast.setOnClickListener {
            val tanggal = etTanggal.text.toString()
            val jam = etJam.text.toString()
            val pesan = "Tanggal: $tanggal, Jam: $jam"
            Toast.makeText(applicationContext, pesan, Toast.LENGTH_SHORT).show()
            Log.i(TAG, "Toast ditampilkan dengan isi: $pesan")
        }
    }

    private fun tampilkanDatePicker() {
        val kalender = Calendar.getInstance()
        val tahun = kalender.get(Calendar.YEAR)
        val bulan = kalender.get(Calendar.MONTH)
        val hari = kalender.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val tanggalFix = String.format(Locale.getDefault(), "%02d-%02d-%04d", dayOfMonth, month + 1, year)
            etTanggal.setText(tanggalFix)
            Toast.makeText(applicationContext, "Tanggal dipilih: $tanggalFix", Toast.LENGTH_SHORT).show()
            Log.d(TAG, "Tanggal dipilih: $tanggalFix")
        }, tahun, bulan, hari)

        datePickerDialog.show()
    }

    private fun tampilkanTimePicker() {
        val kalender = Calendar.getInstance()
        val jam = kalender.get(Calendar.HOUR_OF_DAY)
        val menit = kalender.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(this, { _, hourOfDay, minute ->
            val periode = if (hourOfDay < 12) "AM" else "PM"
            val jamTampil = if (hourOfDay == 0 || hourOfDay == 12) 12 else hourOfDay % 12
            val waktuFix = String.format(Locale.getDefault(), "%02d:%02d %s", jamTampil, minute, periode)
            etJam.setText(waktuFix)
            Toast.makeText(applicationContext, "Jam dipilih: $waktuFix", Toast.LENGTH_SHORT).show()
            Log.d(TAG, "Jam dipilih: $waktuFix")
        }, jam, menit, false)

        timePickerDialog.show()
    }
}
