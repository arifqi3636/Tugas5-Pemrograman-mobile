package com.example.hewan

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class ListChatActivity : AppCompatActivity() {
    val chatList = arrayOf("Kucing: Meoww~~~ (Halo!)", "Anjing: Guk guk (Halo Juga!)", "Burung: Cuit cuit (Pagi semuanya~)", "Kelinci: Nyam nyam nyam..", "Ular: SSHHH...(Aku datang! whahaha~~)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listchat)

        val listView = findViewById<ListView>(R.id.chatListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, chatList)
        listView.adapter = adapter
    }
}
